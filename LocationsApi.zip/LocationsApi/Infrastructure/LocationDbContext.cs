﻿using LocationsApi.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace LocationsApi.Infrastructure
{
    public class LocationDbContext : DbContext
    {
        public LocationDbContext(DbContextOptions<LocationDbContext> options) : base(options)
        {
        }

        public DbSet<Location> Locations { get; set; }

        protected override void ConfigureConventions(ModelConfigurationBuilder builder)
        {
            builder.Properties<TimeOnly>()
                .HaveConversion<TimeOnlyConverter>()
                .HaveColumnType("time");
        }

        private class TimeOnlyConverter : ValueConverter<TimeOnly, TimeSpan>
        {
            /// <summary>
            ///     Creates a new instance of this converter.
            /// </summary>
            public TimeOnlyConverter() : base(
                d => d.ToTimeSpan(),
                d => TimeOnly.FromTimeSpan(d))
            {
            }
        }
    }
}